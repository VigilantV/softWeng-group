from locust import task, run_single_user
from locust import FastHttpUser

class mytest(FastHttpUser):
    #wait_time = 1
    host = "http://localhost"
    default_headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
        "sec-ch-ua": '"Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
    }

    @task(3)
    def like_comment(self):
        with self.client.request(
            "POST",
            "/humhub/index.php?r=user%2Fauth%2Flogout",
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
                "Cache-Control": "max-age=0",
                "Connection": "keep-alive",
                "Content-Length": "98",
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": "PHPSESSID=u3tku7d2hbghs5kmdspcl5ro2m; _csrf=247dac070eed4c2cc1c2cb25058237c8afd84eda9c52afc7b898e8357d83f48ea%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22sWzfJxYF-0kvzx_7VHDveswHZZR4AZ_i%22%3B%7D",
                "Host": "localhost",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
            },
            data="_csrf=kax9q93Ca0-2LxK9OyuEA5mJ1YvPnfzOW4L2-3wcgqHi-wfNl7oyCZsfectBU9s0z8GR_arui4YB2KTPPUbdyA%3D%3D",
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=dashboard%2Fdashboard",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=user%2Fauth%2Flogin",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/assets/siteicons/192x192.png?v=1688227877",
            headers={
                "Referer": "http://localhost/humhub/index.php?r=user%2Fauth%2Flogin"
            },
            catch_response=True,
        ) as resp:
            pass
    
    @task(2)
    def new_post(self):
        with self.client.request(
            "POST",
            "/humhub/index.php?r=user%2Fauth%2Flogout",
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
                "Cache-Control": "max-age=0",
                "Connection": "keep-alive",
                "Content-Length": "98",
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": "PHPSESSID=ajkicbto5pg07nh1mi81d9fnsm; _csrf=e4768d06d46113c83e23e1f2a80d3e7de2982f065292f107c61f860b12e26854a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22u3NH_7LjTE5BIwrozUkwyGQ5zmyZpRcC%22%3B%7D",
                "Host": "localhost",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
            },
            data="_csrf=xLA7qDOylSJLS4LIzdjUb6eamlopoaHTJLbPdAHXia-xg3XgbIXZSB8Ot4qEr6YA3c_xLVDm8OZe27YucYXq7A%3D%3D",
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=dashboard%2Fdashboard",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=user%2Fauth%2Flogin",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/assets/siteicons/192x192.png?v=1688227877",
            headers={
                "Referer": "http://localhost/humhub/index.php?r=user%2Fauth%2Flogin"
            },
            catch_response=True,
        ) as resp:
            pass
    
    @task(2)
    def poll(self):
        with self.client.request(
            "POST",
            "/humhub/index.php?r=user%2Fauth%2Flogout",
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
                "Cache-Control": "max-age=0",
                "Connection": "keep-alive",
                "Content-Length": "98",
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": "PHPSESSID=offmhq7s460pgm8jrhf860rnse; _csrf=b5b328c8643aca58dda158a1622599879359f0622acfaeea37e42f5b03beda08a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22aJPJVQyDda1B2xo2vPaErqItPMxOw5WI%22%3B%7D",
                "Host": "localhost",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&contentId=17&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
            },
            data="_csrf=BlCK4WrWFT1TNre7-kAr4PCjBHFoJQ3yZLf6JDQ-nHdnGtqrPIdseTdXhvnIOETShvNlNBpURIY0-oJrQwvLPg%3D%3D",
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=dashboard%2Fdashboard",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&contentId=17&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=user%2Fauth%2Flogin",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=space%2Fspace&contentId=17&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/assets/siteicons/192x192.png?v=1688227877",
            headers={
                "Referer": "http://localhost/humhub/index.php?r=user%2Fauth%2Flogin"
            },
            catch_response=True,
        ) as resp:
            pass
    
    @task(1)
    def edit_post(self):
        with self.client.request(
            "POST",
            "/humhub/index.php?r=user%2Fauth%2Flogout",
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
                "Cache-Control": "max-age=0",
                "Connection": "keep-alive",
                "Content-Length": "98",
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": "PHPSESSID=5l8559q1cola03f2q68cka9dd0; _csrf=be0386286e3974d9b120d80dcbf02ccdf54a60d0d8b9e23aa1bfc7b8df272b70a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22NTLeKb1NE0oovKFvokH31pEgwYPmtX5W%22%3B%7D",
                "Host": "localhost",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=post%2Fpost%2Fview&id=3&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
            },
            data="_csrf=tgxyqstdocQCUN11tfZUVT8zo9zXrLhCFYdgiBbLl934WD7PgD-QikdgshrDvRIjUFjr7-bc_SVi3jDlYpOiig%3D%3D",
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=dashboard%2Fdashboard",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=post%2Fpost%2Fview&id=3&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=user%2Fauth%2Flogin",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=post%2Fpost%2Fview&id=3&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/assets/siteicons/192x192.png?v=1688227877",
            headers={
                "Referer": "http://localhost/humhub/index.php?r=user%2Fauth%2Flogin"
            },
            catch_response=True,
        ) as resp:
            pass
    
    @task(1)
    def event(self):
        with self.client.request(
            "POST",
            "/humhub/index.php?r=user%2Fauth%2Flogout",
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
                "Cache-Control": "max-age=0",
                "Connection": "keep-alive",
                "Content-Length": "98",
                "Content-Type": "application/x-www-form-urlencoded",
                "Cookie": "PHPSESSID=upvrurs3utjb1q5dpe372lc5ko; _csrf=819fe59c74367a66a25a99b6e1a66f7a876493d36d2535d4604f20d919fc4243a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%224DGa5UsQn4mZXKIgFPDsqPRctQH4XVzR%22%3B%7D",
                "Host": "localhost",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=calendar%2Fentry%2Fview&id=1&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
            },
            data="_csrf=uZ3zslwdCFv0Sq1qMgDhJt5EIourebeJ4mi5Nw_gsHON2bTTaUh7Cpp-wDBqS6hBmBRm-Nop5eqWOfEDV7bKIQ%3D%3D",
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=dashboard%2Fdashboard",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=calendar%2Fentry%2Fview&id=1&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/index.php?r=user%2Fauth%2Flogin",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "http://localhost",
                "Referer": "http://localhost/humhub/index.php?r=calendar%2Fentry%2Fview&id=1&cguid=b2e5ffa5-a8c3-42b4-afcc-e18ba70aca31",
                "Upgrade-Insecure-Requests": "1",
            },
            catch_response=True,
        ) as resp:
            pass
        with self.client.request(
            "GET",
            "/humhub/assets/siteicons/192x192.png?v=1688227877",
            headers={
                "Referer": "http://localhost/humhub/index.php?r=user%2Fauth%2Flogin"
            },
            catch_response=True,
        ) as resp:
            pass


if __name__ == "__main__":
    run_single_user(mytest)
